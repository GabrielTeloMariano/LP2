﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_limpar_Click(object sender, EventArgs e)
        {
            rtb_texto.Clear();
            lbl_posEspaco1.Text = "";
            lbl_qtdLetras.Text = "";
            lbl_qtdNmr.Text = "";

        }

        private void btnQtdLetras_Click(object sender, EventArgs e)
        {
            int count = 0;
            foreach(char c in rtb_texto.Text)
            {
                if (char.IsLetter(c))
                {
                    count++;
                }
            }
            lbl_qtdLetras.Text = count.ToString();
        }

        private void btnQtdNmr_Click(object sender, EventArgs e)
        {
            int count = 0;
            for (int i = 0; i < rtb_texto.Text.Length; i++)
            {
                if (char.IsNumber(rtb_texto.Text[i]))
                {
                    count++;
                }
            }
            lbl_qtdNmr.Text = count.ToString();
        }

        private void btnEspaco1_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            while (posicao < rtb_texto.Text.Length && !Char.IsWhiteSpace(rtb_texto.Text[posicao]))
            {
                posicao++;
            }
            if (posicao < rtb_texto.Text.Length)
            {
                lbl_posEspaco1.Text = posicao.ToString();
            }
            else
            {
                lbl_posEspaco1.Text = "Não há espaços em branco";
            }
        }
    }
}