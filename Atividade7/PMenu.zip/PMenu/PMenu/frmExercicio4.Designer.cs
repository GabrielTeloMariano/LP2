﻿namespace PMenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtb_texto = new System.Windows.Forms.RichTextBox();
            this.btnQtdNmr = new System.Windows.Forms.Button();
            this.btnEspaco1 = new System.Windows.Forms.Button();
            this.btnQtdLetras = new System.Windows.Forms.Button();
            this.lbl_instru = new System.Windows.Forms.Label();
            this.btn_fechar = new System.Windows.Forms.Button();
            this.btn_limpar = new System.Windows.Forms.Button();
            this.lbl_qtdLetras = new System.Windows.Forms.Label();
            this.lbl_qtdNmr = new System.Windows.Forms.Label();
            this.lbl_posEspaco1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rtb_texto
            // 
            this.rtb_texto.Location = new System.Drawing.Point(40, 70);
            this.rtb_texto.Name = "rtb_texto";
            this.rtb_texto.Size = new System.Drawing.Size(496, 135);
            this.rtb_texto.TabIndex = 0;
            this.rtb_texto.Text = "";
            // 
            // btnQtdNmr
            // 
            this.btnQtdNmr.Location = new System.Drawing.Point(131, 227);
            this.btnQtdNmr.Name = "btnQtdNmr";
            this.btnQtdNmr.Size = new System.Drawing.Size(109, 32);
            this.btnQtdNmr.TabIndex = 1;
            this.btnQtdNmr.Text = "Qtd números";
            this.btnQtdNmr.UseVisualStyleBackColor = true;
            this.btnQtdNmr.Click += new System.EventHandler(this.btnQtdNmr_Click);
            // 
            // btnEspaco1
            // 
            this.btnEspaco1.Location = new System.Drawing.Point(246, 227);
            this.btnEspaco1.Name = "btnEspaco1";
            this.btnEspaco1.Size = new System.Drawing.Size(141, 32);
            this.btnEspaco1.TabIndex = 2;
            this.btnEspaco1.Text = "Posição 1° espaço";
            this.btnEspaco1.UseVisualStyleBackColor = true;
            this.btnEspaco1.Click += new System.EventHandler(this.btnEspaco1_Click);
            // 
            // btnQtdLetras
            // 
            this.btnQtdLetras.Location = new System.Drawing.Point(40, 227);
            this.btnQtdLetras.Name = "btnQtdLetras";
            this.btnQtdLetras.Size = new System.Drawing.Size(85, 32);
            this.btnQtdLetras.TabIndex = 3;
            this.btnQtdLetras.Text = "QtdLetras";
            this.btnQtdLetras.UseVisualStyleBackColor = true;
            this.btnQtdLetras.Click += new System.EventHandler(this.btnQtdLetras_Click);
            // 
            // lbl_instru
            // 
            this.lbl_instru.AutoSize = true;
            this.lbl_instru.Location = new System.Drawing.Point(40, 51);
            this.lbl_instru.Name = "lbl_instru";
            this.lbl_instru.Size = new System.Drawing.Size(101, 17);
            this.lbl_instru.TabIndex = 4;
            this.lbl_instru.Text = "Digite um texto";
            // 
            // btn_fechar
            // 
            this.btn_fechar.Location = new System.Drawing.Point(493, 379);
            this.btn_fechar.Name = "btn_fechar";
            this.btn_fechar.Size = new System.Drawing.Size(73, 26);
            this.btn_fechar.TabIndex = 5;
            this.btn_fechar.Text = "Fechar";
            this.btn_fechar.UseVisualStyleBackColor = true;
            this.btn_fechar.Click += new System.EventHandler(this.btn_fechar_Click);
            // 
            // btn_limpar
            // 
            this.btn_limpar.Location = new System.Drawing.Point(468, 227);
            this.btn_limpar.Name = "btn_limpar";
            this.btn_limpar.Size = new System.Drawing.Size(68, 32);
            this.btn_limpar.TabIndex = 6;
            this.btn_limpar.Text = "Limpar";
            this.btn_limpar.UseVisualStyleBackColor = true;
            this.btn_limpar.Click += new System.EventHandler(this.btn_limpar_Click);
            // 
            // lbl_qtdLetras
            // 
            this.lbl_qtdLetras.AutoSize = true;
            this.lbl_qtdLetras.Location = new System.Drawing.Point(40, 262);
            this.lbl_qtdLetras.Name = "lbl_qtdLetras";
            this.lbl_qtdLetras.Size = new System.Drawing.Size(48, 17);
            this.lbl_qtdLetras.TabIndex = 7;
            this.lbl_qtdLetras.Text = "Letras";
            // 
            // lbl_qtdNmr
            // 
            this.lbl_qtdNmr.AutoSize = true;
            this.lbl_qtdNmr.Location = new System.Drawing.Point(128, 262);
            this.lbl_qtdNmr.Name = "lbl_qtdNmr";
            this.lbl_qtdNmr.Size = new System.Drawing.Size(65, 17);
            this.lbl_qtdNmr.TabIndex = 8;
            this.lbl_qtdNmr.Text = "Numeros";
            // 
            // lbl_posEspaco1
            // 
            this.lbl_posEspaco1.AutoSize = true;
            this.lbl_posEspaco1.Location = new System.Drawing.Point(243, 262);
            this.lbl_posEspaco1.Name = "lbl_posEspaco1";
            this.lbl_posEspaco1.Size = new System.Drawing.Size(55, 17);
            this.lbl_posEspaco1.TabIndex = 9;
            this.lbl_posEspaco1.Text = "Espaço";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 417);
            this.Controls.Add(this.lbl_posEspaco1);
            this.Controls.Add(this.lbl_qtdNmr);
            this.Controls.Add(this.lbl_qtdLetras);
            this.Controls.Add(this.btn_limpar);
            this.Controls.Add(this.btn_fechar);
            this.Controls.Add(this.lbl_instru);
            this.Controls.Add(this.btnQtdLetras);
            this.Controls.Add(this.btnEspaco1);
            this.Controls.Add(this.btnQtdNmr);
            this.Controls.Add(this.rtb_texto);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtb_texto;
        private System.Windows.Forms.Button btnQtdNmr;
        private System.Windows.Forms.Button btnEspaco1;
        private System.Windows.Forms.Button btnQtdLetras;
        private System.Windows.Forms.Label lbl_instru;
        private System.Windows.Forms.Button btn_fechar;
        private System.Windows.Forms.Button btn_limpar;
        private System.Windows.Forms.Label lbl_qtdLetras;
        private System.Windows.Forms.Label lbl_qtdNmr;
        private System.Windows.Forms.Label lbl_posEspaco1;
    }
}