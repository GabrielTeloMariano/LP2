﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio5 : Form
    {
        double numero1, numero2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Número 1 inválido");
            }
            else
            {
                numero1 = Convert.ToDouble(txtNumero1.Text);
            }
        }

        private void txtNumero2_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido");
            }
            else
            {
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            Random rdn = new Random();
            double sorteio = rdn.Next(Convert.ToInt32(numero1), Convert.ToInt32(numero2)+1);
            lblNmrSorteado.Text = "" + sorteio;
        }

    }
}
