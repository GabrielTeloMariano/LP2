﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2;

        public Form1()
        {
            InitializeComponent();
        }    
        
        private void txtNmr1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNmr1.Text, out numero1))
            {
                MessageBox.Show("Número 1 inválido");
            }
        }

        private void txtNmr2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNmr2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido");
            }
        }
       
        private void btnSoma_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (double.Parse(txtNmr1.Text) + double.Parse(txtNmr2.Text)).ToString();
        }
       
        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (double.Parse(txtNmr1.Text) - double.Parse(txtNmr2.Text)).ToString();
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (double.Parse(txtNmr1.Text) * double.Parse(txtNmr2.Text)).ToString();
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (double.Parse(txtNmr2.Text) == 0)
            {
                MessageBox.Show("Não existe divisão por zero >:(");
            }
            else
            {
                txtResultado.Text = (double.Parse(txtNmr1.Text) / double.Parse(txtNmr2.Text)).ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNmr1.Clear();
            txtNmr2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }     
    
}
