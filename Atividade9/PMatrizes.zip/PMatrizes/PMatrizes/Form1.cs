﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetInt = new int[20];
            int i;

            for (i=0; i<20; i++)
            {
                var input = Interaction.InputBox("Digite um número inteiro: ", "Entrada de dados",i.ToString()+"/20");
                if (!int.TryParse(input, out int numero))
                {
                    MessageBox.Show("Digite somente números inteiros");
                    i--;
                }
                vetInt[i] = numero;
            }

            Array.Reverse(vetInt);

            foreach(var item in vetInt)
            {
                MessageBox.Show(item.ToString());
            }
            
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            double[] quantidade = new double[10];
            double[] preco = new double[10];
            double faturamento = 0;
            
            for (var i = 0; i < 10; i++)
            {
                var input = Interaction.InputBox("Digite a quantidade:", "Entrada de dados", (i+1).ToString()+"/10");
                if (!double.TryParse(input, out quantidade[i]))
                {
                    MessageBox.Show("Quantidade inválida");
                    i--;
                }
                else
                {
                    while (preco[i] <= 0)
                    {
                        //input = "";
                        input = Interaction.InputBox("Digite o preço:", "Entrada de dados", (i+1).ToString()+"/10");
                        if (!double.TryParse(input, out preco[i]))
                        {
                            MessageBox.Show("Preço inválido");
                        }
                    }
                    faturamento += quantidade[i] * preco[i];
                }

            }
            MessageBox.Show("Faturamento: " + faturamento.ToString("N2")); ;
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            ArrayList listaAlunos = new ArrayList();

            listaAlunos.Add("Ana");
            listaAlunos.Add("André");
            listaAlunos.Add("Débora");
            listaAlunos.Add("Fátima");
            listaAlunos.Add("João");
            listaAlunos.Add("Janete");
            listaAlunos.Add("Otávio");
            listaAlunos.Add("Marcelo");
            listaAlunos.Add("Pedro");
            listaAlunos.Add("Thais");

            for (var i = listaAlunos.Count - 1; i >= 0; i--)
            {
                if (string.Compare(listaAlunos[i].ToString(), "Otávio") == 0)
                {
                    MessageBox.Show("Nome a ser excluído: " + listaAlunos[i].ToString());
                    listaAlunos.RemoveAt(i);
                    break;
                }
            }

            string novaLista = string.Join("\n", listaAlunos.ToArray());
            MessageBox.Show("Nomes: \n" + novaLista);
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            var frmEx5e6 = Application.OpenForms.OfType<frmExercicios5e6>().FirstOrDefault();
            if (frmEx5e6 != null)
            {
                frmEx5e6.BringToFront();
            }
            else
            {
                frmEx5e6 = new frmExercicios5e6();
                frmEx5e6.Show();
            }
        }
    }
}
