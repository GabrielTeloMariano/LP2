﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class frmExercicios5e6 : Form
    {
        public frmExercicios5e6()
        {
            InitializeComponent();
        }

        private void btnMedias_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] medias = new double[20];

            for (var i = 0; i < notas.GetLength(0); i++)
            {
                double media = 0;
                notas[i, 0] = i;

                for (var j = 0; j < notas.GetLength(1); j++)
                {
                    notas[i, j] = double.Parse(Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}: ", $"Entrada aluno {i + 1}"));
                    media += notas[i, j];
                }

                medias[i] = media / 3;
            }

            for (var i = 0; i < medias.GetLength(0); i++)
            {
                lstbxLista.Items.Add($"Aluno {i + 1}: média: {medias[i].ToString("N1")}");
            }
        }

        private void btnListaAlunos_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[8];
            int[] tamanhos = new int[8];

            for (var i = 0; i < nomes.Length; i++)
            {
                nomes[i] = Interaction.InputBox($"Digite seu nome completo:", "ENTRADA");
                tamanhos[i] = nomes[i].Replace(" ", "").Length;
            }

            for (var i = 0; i < nomes.Length; i++)
            {
                lstbxLista.Items.Add($"O nome: {nomes[i]} tem {tamanhos[i]} caracteres");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxLista.Items.Clear();
        }
    }
}
