﻿
namespace PMatrizes
{
    partial class frmExercicios5e6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMedias = new System.Windows.Forms.Button();
            this.btnListaAlunos = new System.Windows.Forms.Button();
            this.lstbxLista = new System.Windows.Forms.ListBox();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMedias
            // 
            this.btnMedias.Location = new System.Drawing.Point(25, 41);
            this.btnMedias.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnMedias.Name = "btnMedias";
            this.btnMedias.Size = new System.Drawing.Size(138, 42);
            this.btnMedias.TabIndex = 0;
            this.btnMedias.Text = "Medias";
            this.btnMedias.UseVisualStyleBackColor = true;
            this.btnMedias.Click += new System.EventHandler(this.btnMedias_Click);
            // 
            // btnListaAlunos
            // 
            this.btnListaAlunos.Location = new System.Drawing.Point(25, 411);
            this.btnListaAlunos.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnListaAlunos.Name = "btnListaAlunos";
            this.btnListaAlunos.Size = new System.Drawing.Size(138, 42);
            this.btnListaAlunos.TabIndex = 1;
            this.btnListaAlunos.Text = "Lista Alunos";
            this.btnListaAlunos.UseVisualStyleBackColor = true;
            this.btnListaAlunos.Click += new System.EventHandler(this.btnListaAlunos_Click);
            // 
            // lstbxLista
            // 
            this.lstbxLista.FormattingEnabled = true;
            this.lstbxLista.ItemHeight = 24;
            this.lstbxLista.Location = new System.Drawing.Point(323, 41);
            this.lstbxLista.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.lstbxLista.Name = "lstbxLista";
            this.lstbxLista.Size = new System.Drawing.Size(429, 412);
            this.lstbxLista.TabIndex = 2;
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(755, 497);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(105, 37);
            this.btnFechar.TabIndex = 3;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(624, 497);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(99, 37);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // frmExercicios5e6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 546);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.lstbxLista);
            this.Controls.Add(this.btnListaAlunos);
            this.Controls.Add(this.btnMedias);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frmExercicios5e6";
            this.Text = "frmExercicios5e6";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMedias;
        private System.Windows.Forms.Button btnListaAlunos;
        private System.Windows.Forms.ListBox lstbxLista;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Button btnLimpar;
    }
}