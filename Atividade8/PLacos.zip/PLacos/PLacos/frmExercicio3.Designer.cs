﻿namespace PLacos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFrase = new System.Windows.Forms.TextBox();
            this.btnInverter = new System.Windows.Forms.Button();
            this.btnEhPalindromo = new System.Windows.Forms.Button();
            this.lblFrase = new System.Windows.Forms.Label();
            this.btnFechar = new System.Windows.Forms.Button();
            this.lblBoolean = new System.Windows.Forms.Label();
            this.txtInvertido = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtFrase
            // 
            this.txtFrase.Location = new System.Drawing.Point(19, 93);
            this.txtFrase.Margin = new System.Windows.Forms.Padding(6);
            this.txtFrase.Name = "txtFrase";
            this.txtFrase.Size = new System.Drawing.Size(378, 29);
            this.txtFrase.TabIndex = 0;
            // 
            // btnInverter
            // 
            this.btnInverter.Location = new System.Drawing.Point(434, 80);
            this.btnInverter.Margin = new System.Windows.Forms.Padding(6);
            this.btnInverter.Name = "btnInverter";
            this.btnInverter.Size = new System.Drawing.Size(138, 42);
            this.btnInverter.TabIndex = 1;
            this.btnInverter.Text = "Inverter";
            this.btnInverter.UseVisualStyleBackColor = true;
            this.btnInverter.Click += new System.EventHandler(this.btnInverter_Click);
            // 
            // btnEhPalindromo
            // 
            this.btnEhPalindromo.Location = new System.Drawing.Point(19, 194);
            this.btnEhPalindromo.Margin = new System.Windows.Forms.Padding(6);
            this.btnEhPalindromo.Name = "btnEhPalindromo";
            this.btnEhPalindromo.Size = new System.Drawing.Size(152, 65);
            this.btnEhPalindromo.TabIndex = 2;
            this.btnEhPalindromo.Text = "É palíndromo?";
            this.btnEhPalindromo.UseVisualStyleBackColor = true;
            this.btnEhPalindromo.Click += new System.EventHandler(this.btnEhPalindromo_Click);
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Location = new System.Drawing.Point(15, 41);
            this.lblFrase.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(365, 24);
            this.lblFrase.TabIndex = 3;
            this.lblFrase.Text = "Digite uma palavra ou texto de até 50 char:";
            // 
            // btnFechar
            // 
            this.btnFechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.Location = new System.Drawing.Point(467, 317);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(105, 38);
            this.btnFechar.TabIndex = 4;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // lblBoolean
            // 
            this.lblBoolean.AutoSize = true;
            this.lblBoolean.Location = new System.Drawing.Point(262, 245);
            this.lblBoolean.Name = "lblBoolean";
            this.lblBoolean.Size = new System.Drawing.Size(0, 24);
            this.lblBoolean.TabIndex = 6;
            // 
            // txtInvertido
            // 
            this.txtInvertido.Location = new System.Drawing.Point(19, 134);
            this.txtInvertido.Margin = new System.Windows.Forms.Padding(6);
            this.txtInvertido.Name = "txtInvertido";
            this.txtInvertido.ReadOnly = true;
            this.txtInvertido.Size = new System.Drawing.Size(378, 29);
            this.txtInvertido.TabIndex = 7;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(19, 317);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(105, 38);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 367);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtInvertido);
            this.Controls.Add(this.lblBoolean);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.btnEhPalindromo);
            this.Controls.Add(this.btnInverter);
            this.Controls.Add(this.txtFrase);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtFrase;
        private System.Windows.Forms.Button btnInverter;
        private System.Windows.Forms.Button btnEhPalindromo;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Label lblBoolean;
        private System.Windows.Forms.TextBox txtInvertido;
        private System.Windows.Forms.Button btnLimpar;
    }
}