﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class frmExercicio3 : Form
    {
        string minuscula;
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnInverter_Click(object sender, EventArgs e)
        {
            minuscula = txtFrase.Text.ToLower();
            txtInvertido.Clear();

            for (int i = txtFrase.Text.Length - 1; i>=0; i--)
            {
                txtInvertido.Text += minuscula[i];
            }
           
        }

        private void btnEhPalindromo_Click(object sender, EventArgs e)
        {
            if (minuscula.Replace(" ","") == txtInvertido.Text.Replace(" ", ""))
            {
                lblBoolean.Text = "SIM";
            }
            else
            {
                lblBoolean.Text = "NÃO";
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtInvertido.Clear();
            txtFrase.Clear();
            lblBoolean.Text = "";
        }
    }
}
