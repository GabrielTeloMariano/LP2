﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class frmExercicio2 : Form
    {
        double num1;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtNumero_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero.Text, out num1))
            {
                MessageBox.Show("Precisa ser um número inteiro");
            }
            else
            {
                num1 = Convert.ToDouble(txtNumero.Text);
                if (num1 <= 0)
                {
                    MessageBox.Show("Precisa ser maior do que zero (positivo)");
                }
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            lblValorH.Text = "";
            double valorH = 0;
            
            for (int i = 1; i <= Convert.ToDouble(txtNumero.Text); i++)
            {
                valorH += (1 /(double)i);
            }

            lblValorH.Text = "H = " + valorH.ToString("N5");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero.Clear();
            lblValorH.Text = "";
        }
    }
}
