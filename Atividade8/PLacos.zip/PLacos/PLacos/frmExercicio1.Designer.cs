﻿namespace PLacos
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspacosBrancos = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnParLetras = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnFechar = new System.Windows.Forms.Button();
            this.lblEspacosBrancos = new System.Windows.Forms.Label();
            this.lblLetrasR = new System.Windows.Forms.Label();
            this.lblParesLetras = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(15, 70);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(6);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(648, 183);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnEspacosBrancos
            // 
            this.btnEspacosBrancos.Location = new System.Drawing.Point(15, 299);
            this.btnEspacosBrancos.Margin = new System.Windows.Forms.Padding(6);
            this.btnEspacosBrancos.Name = "btnEspacosBrancos";
            this.btnEspacosBrancos.Size = new System.Drawing.Size(135, 62);
            this.btnEspacosBrancos.TabIndex = 1;
            this.btnEspacosBrancos.Text = "Qtd espaços em branco";
            this.btnEspacosBrancos.UseVisualStyleBackColor = true;
            this.btnEspacosBrancos.Click += new System.EventHandler(this.BtnEspacosBrancos_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(280, 299);
            this.btnLetraR.Margin = new System.Windows.Forms.Padding(6);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(135, 62);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Qtd de letras \'R\'";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnParLetras
            // 
            this.btnParLetras.Location = new System.Drawing.Point(528, 299);
            this.btnParLetras.Margin = new System.Windows.Forms.Padding(6);
            this.btnParLetras.Name = "btnParLetras";
            this.btnParLetras.Size = new System.Drawing.Size(135, 62);
            this.btnParLetras.TabIndex = 3;
            this.btnParLetras.Text = "Qtd de pares de letras";
            this.btnParLetras.UseVisualStyleBackColor = true;
            this.btnParLetras.Click += new System.EventHandler(this.btnParLetras_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(15, 35);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(344, 24);
            this.lblTitulo.TabIndex = 4;
            this.lblTitulo.Text = "Digite uma frase de até 100 characteres:";
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(730, 442);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(109, 37);
            this.btnFechar.TabIndex = 5;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // lblEspacosBrancos
            // 
            this.lblEspacosBrancos.AutoSize = true;
            this.lblEspacosBrancos.Location = new System.Drawing.Point(56, 396);
            this.lblEspacosBrancos.Name = "lblEspacosBrancos";
            this.lblEspacosBrancos.Size = new System.Drawing.Size(0, 24);
            this.lblEspacosBrancos.TabIndex = 6;
            // 
            // lblLetrasR
            // 
            this.lblLetrasR.AutoSize = true;
            this.lblLetrasR.Location = new System.Drawing.Point(323, 396);
            this.lblLetrasR.Name = "lblLetrasR";
            this.lblLetrasR.Size = new System.Drawing.Size(0, 24);
            this.lblLetrasR.TabIndex = 7;
            // 
            // lblParesLetras
            // 
            this.lblParesLetras.AutoSize = true;
            this.lblParesLetras.Location = new System.Drawing.Point(571, 396);
            this.lblParesLetras.Name = "lblParesLetras";
            this.lblParesLetras.Size = new System.Drawing.Size(0, 24);
            this.lblParesLetras.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(730, 396);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 37);
            this.button1.TabIndex = 9;
            this.button1.Text = "Limpar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 491);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblParesLetras);
            this.Controls.Add(this.lblLetrasR);
            this.Controls.Add(this.lblEspacosBrancos);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnParLetras);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspacosBrancos);
            this.Controls.Add(this.rchtxtFrase);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnEspacosBrancos;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnParLetras;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Label lblEspacosBrancos;
        private System.Windows.Forms.Label lblLetrasR;
        private System.Windows.Forms.Label lblParesLetras;
        private System.Windows.Forms.Button button1;
    }
}