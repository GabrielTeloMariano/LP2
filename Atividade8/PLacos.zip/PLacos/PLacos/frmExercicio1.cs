﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void BtnEspacosBrancos_Click(object sender, EventArgs e)
        {
            lblEspacosBrancos.Text = "";
            int tamanho = rchtxtFrase.Text.Length - rchtxtFrase.Text.Replace(" ", "").Length;
            lblEspacosBrancos.Text = tamanho.ToString();
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int totalR = 0;

            foreach(char letraR in rchtxtFrase.Text)
            {
                if (char.ToLower(letraR) == 'r')
                {
                    totalR += 1;
                }
            }

            lblLetrasR.Text = totalR.ToString();
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int totalPar = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length-1; i++)
            {
                if (char.ToLower(rchtxtFrase.Text[i]) == char.ToLower(rchtxtFrase.Text[(i + 1)]))
                {
                    totalPar += 1;
                }
            }

            lblParesLetras.Text = totalPar.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            rchtxtFrase.Clear();
            lblEspacosBrancos.Text = "";
            lblLetrasR.Text = "";
            lblParesLetras.Text = "";
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
