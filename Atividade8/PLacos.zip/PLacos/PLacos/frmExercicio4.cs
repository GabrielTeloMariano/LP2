﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class frmExercicio4 : Form
    {
        double salario, salarioBruto, gratificacao, producao;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            double l;
            if (!double.TryParse(txtProducao.Text, out l) || l < 0)
            {
                MessageBox.Show("Produção inválida");
            }
            else
            {
                producao = Convert.ToDouble(txtProducao.Text);
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            double m;
            if (!double.TryParse(txtSalario.Text, out m) || m < 0)
            {
                MessageBox.Show("Salário inválido");
            }
            else
            {
                salario = Convert.ToDouble(txtSalario.Text);
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            double n;
            if (!double.TryParse(txtGratificacao.Text, out n) || n < 0)
            {
                MessageBox.Show("Gratificação inválida");
            }
            else
            {
                gratificacao = Convert.ToDouble(txtGratificacao.Text);
            }
        }

        private void btnCalcularSalario_Click(object sender, EventArgs e)
        {        

            if (producao >= 150)
            {
                salarioBruto = salario + salario * (0.05 + 0.1 + 0.1) + gratificacao;
            }
            else if (producao >= 120)
            {
                salarioBruto = salario + salario * (0.05 + 0.1) + gratificacao;
            }
            else if (producao >= 100)
            {
                salarioBruto = salario + salario * (0.05) + gratificacao;
            }
            else
            {
                salarioBruto = salario + gratificacao;
            }
        

            txtSalarioBruto.Text = salarioBruto.ToString("N2");

            if (salarioBruto >= 7000 && producao < 150 || salarioBruto >= 7000 && gratificacao == 0)
            {
                txtSalarioBruto.Clear();
                MessageBox.Show("Salário acima de 7 mil só poderá ser pago aos funcionários cuja produção seja >= 150, além de ser necessário ter recebido a gratificação");
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtCargo.Clear();
            txtMatricula.Clear();
            txtSalario.Clear();
            txtProducao.Clear();
            txtGratificacao.Clear();
            txtSalarioBruto.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
