﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC, modAB, modAC, modBC;

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            lblTriangTipo.Text = "";
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Valor A Inválido");
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Valor B Inválido");
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Valor C Inválido");
            }
        }
        private void btnTestar_Click(object sender, EventArgs e)
        {
            ladoA = double.Parse(txtLadoA.Text);
            ladoB = double.Parse(txtLadoB.Text);
            ladoC = double.Parse(txtLadoC.Text);
            modAB = Math.Abs(ladoA - ladoB);
            modAC = Math.Abs(ladoA - ladoC);
            modBC = Math.Abs(ladoB - ladoC);

            if (modBC < ladoA && ladoA < (ladoB + ladoC) && modAC < ladoB && ladoB < (ladoA + ladoC) &&
                modAB < ladoC && ladoC < ladoB + ladoC)
            {
                if (ladoA == ladoB && ladoA == ladoC)
                {
                    lblTriangTipo.Text = "Sim, é um triângulo equilátero";
                }
                else if (ladoA == ladoB && ladoB != ladoC || ladoA == ladoC && ladoA != ladoB || ladoB == ladoC && ladoB != ladoA)
                {
                    lblTriangTipo.Text = "Sim, é um triângulo isósceles";
                }
                else
                    lblTriangTipo.Text = "Sim, é um triângulo escaleno";
            }
            else
                lblTriangTipo.Text = "Não, não é um triângulo";
            
        }


    }

}
